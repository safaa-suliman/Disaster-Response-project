import pandas as pd
from sqlalchemy import create_engine

def load_data(messages_filepath, categories_filepath):
    """
    Load and merge the disaster messages and categories datasets.
    """
    # Load datasets
    messages = pd.read_csv(messages_filepath)
    categories = pd.read_csv(categories_filepath)
    
    # Merge datasets using common ID
    df = pd.merge(messages, categories, on='id')
    
    return df

def clean_data(df):
    """
    Perform data cleaning on the merged dataset.
    """
    # Split categories column into separate category columns
    categories = df['categories'].str.split(';', expand=True)

    # Rename the category columns
    categories.columns = categories.iloc[0].apply(lambda x: x.split('-')[0])
    
    # Convert category values to binary
    for column in categories:
        categories[column] = categories[column].apply(lambda x: int(x.split('-')[1]))
        categories[column] = categories[column].apply(lambda x: 1 if x > 0 else 0)
    
    # Replace the original categories column with the new category columns
    df = pd.concat([df.drop('categories', axis=1), categories], axis=1)

    # Rename the columns
    category_colnames = categories.columns.tolist()
    category_colnames = [name.replace('_', ' ') for name in category_colnames]
    categories.columns = category_colnames
    
    # Drop duplicates
    df.drop_duplicates(inplace=True)
    
    return df

def save_data(df, database_filename):
    """
    Save the cleaned dataset to an SQLite database.
    """
    # Create an engine to connect to an SQLite database
    engine = create_engine('sqlite:///' + database_filename)

    # Save the clean dataset to a table in the database
    df.to_sql('disaster_messages', engine, index=False, if_exists='replace')

def main():
    """
    Load the disaster messages and categories datasets, clean the data, and save it to an SQLite database.
    """
    # Get user input for file paths
    messages_filepath = input("Enter the path to the disaster messages dataset: ")
    categories_filepath = input("Enter the path to the disaster categories dataset: ")
    database_filepath = input("Enter the name of the database to create: ")

    # Load and merge datasets
    print("Loading and merging datasets...")
    df = load_data(messages_filepath, categories_filepath)

    # Clean data
    print("Cleaning data...")
    df = clean_data(df)

    # Save data to SQLite database
    print("Saving data to database...")
    save_data(df, database_filepath)

    # Print number of records in database
    engine = create_engine('sqlite:///' + database_filepath)
    connection = engine.connect()
    print(engine.table_names())  # print the list of tables in the database
    result = connection.execute("SELECT COUNT(*) FROM disaster_messages")
    count = result.fetchone()[0]
    print("Number of records in database:", count)
    connection.close()

if __name__ == '__main__':
    main()
