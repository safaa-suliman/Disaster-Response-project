import sys
import pandas as pd
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.multioutput import MultiOutputClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
import pickle

def load_data(database_filepath):
    """
    Load the data from the SQLite database into a pandas DataFrame
    """
    engine = create_engine('sqlite:///' + database_filepath)
    df = pd.read_sql_table('Disaster_Response', engine)
    X = df['message']
    Y = df.iloc[:, 4:]
    category_names = Y.columns.tolist()
    return X, Y, category_names

def tokenize(text):
    """
    Tokenize the text data by converting to lowercase, removing punctuation and stop words, and lemmatizing
    """
    # import libraries
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem.wordnet import WordNetLemmatizer
    import string

    # convert to lowercase
    text = text.lower()
    # remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # tokenize text
    tokens = word_tokenize(text)
    # remove stop words
    tokens = [t for t in tokens if t not in stopwords.words("english")]
    # lemmatize tokens
    lemmatizer = WordNetLemmatizer()
    clean_tokens = [lemmatizer.lemmatize(token) for token in tokens]

    return clean_tokens

def build_model():
    """
    Build a machine learning pipeline using CountVectorizer, TfidfTransformer, MultiOutputClassifier, and RandomForestClassifier
    """
    pipeline = Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer()),
        ('clf', MultiOutputClassifier(RandomForestClassifier()))
    ])
    
    parameters = {
        'vect__ngram_range': ((1, 1), (1, 2)),
        'tfidf__use_idf': (True, False),
        'clf__estimator__n_estimators': [10, 50],
        'clf__estimator__min_samples_split': [2, 4]
    }

    cv = GridSearchCV(pipeline, param_grid=parameters, verbose=2)

    return cv

def evaluate_model(model, X_train, Y_train, X_test, Y_test, category_names):
    """
    Evaluate the performance of the model on the test set
    """
    # Train and fit the model
    model.fit(X_train, Y_train)
    # Predict on the test set
    Y_pred = model.predict(X_test)
    # Print classification report
    print(classification_report(Y_test.values, Y_pred, target_names=category_names))

def save_model(model, model_filepath):
    """
    Save the model as a pickle file
    """
    with open(model_filepath, 'wb') as file:
        pickle.dump(model.best_estimator_, file)

def main():
    """
    Train the model and save it as a pickle file
    """
    if len(sys.argv) == 4:
        database_filepath, model_filepath, new_data_filepath = sys.argv[1:]
        # Load data
        X, Y, category_names = load_data(database_filepath)
        # Split into train and test sets
        X_train, X_test, Y_train, Y_test
