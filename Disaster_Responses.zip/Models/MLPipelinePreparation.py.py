#!/usr/bin/env python
# coding: utf-8

# # ML Pipeline Preparation
# Follow the instructions below to help you create your ML pipeline.
# ### 1. Import libraries and load data from database.
# - Import Python libraries
# - Load dataset from database with [`read_sql_table`](https://pandas.pydata.org/pandas-docs/stable/generated/pandas.read_sql_table.html)
# - Define feature and target variables X and Y

# In[1]:


import pandas as pd
from sqlalchemy import create_engine
import nltk
nltk.download(['punkt', 'wordnet'])
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.multioutput import MultiOutputClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV


# In[2]:


# Load data from database
engine = create_engine('sqlite:///disaster_messages.db')
print(engine.table_names())  # print the list of tables in the database
df = pd.read_sql_table('disaster_messages', engine)

# Define feature and target variables
X = df['message']
Y = df.drop(['id', 'message', 'original', 'genre'], axis=1)


# ### 2. Write a tokenization function to process your text data

# In[3]:




def tokenize(text):
    """
    Tokenize text data by splitting it into individual words, converting them to lowercase,
    and lemmatizing them (reducing them to their base form).
    
    Args:
    text: str, text data to be tokenized
    
    Returns:
    tokens: list, a list of tokens (individual words) from the text data
    """
    # Convert text to lowercase and tokenize it
    tokens = word_tokenize(text.lower())
    
    # Initialize lemmatizer
    lemmatizer = WordNetLemmatizer()
    
    # Lemmatize each token and remove leading/trailing white space
    tokens = [lemmatizer.lemmatize(token).strip() for token in tokens]
    
    return tokens


# ### 3. Build a machine learning pipeline
# This machine pipeline should take in the `message` column as input and output classification results on the other 36 categories in the dataset. You may find the [MultiOutputClassifier](http://scikit-learn.org/stable/modules/generated/sklearn.multioutput.MultiOutputClassifier.html) helpful for predicting multiple target variables.

# In[4]:




# Define machine learning pipeline
pipeline = Pipeline([
    ('vectorizer', CountVectorizer(tokenizer=tokenize)),
    ('tfidf', TfidfTransformer()),
    ('clf', MultiOutputClassifier(RandomForestClassifier()))
])


# ### 4. Train pipeline
# - Split data into train and test sets
# - Train pipeline

# In[5]:


# Split data into training and test sets
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

# Train pipeline on training data
pipeline.fit(X_train, Y_train)

# Predict categories for test data
Y_pred = pipeline.predict(X_test)


# ### 5. Test your model
# Report the f1 score, precision and recall for each output category of the dataset. You can do this by iterating through the columns and calling sklearn's `classification_report` on each.

# In[6]:


from sklearn.metrics import classification_report

# Get predictions on test data
Y_pred = pipeline.predict(X_test)

# Print classification report for each category
for i, col in enumerate(Y.columns):
    print(f"Category: {col}")
    print(classification_report(Y_test.iloc[:,i], Y_pred[:,i]))


# In[7]:


# Calculate evaluation metrics for training set
#y_train_pred = pipeline.predict(X_train)
#col_names = list(y.columns.values)

#print(get_eval_metrics(np.array(y_train), y_train_pred, col_names))


# In[8]:


# Calculate evaluation metrics for test set
#y_test_pred = pipeline.predict(X_test)

#eval_metrics1 = get_eval_metrics(np.array(y_test), y_test_pred, col_names)
#print(eval_metrics1)


# In[9]:


# Calculating the proportion of each column that have label == 1
#y.sum()/len(y)

# Calculate proportion of each column that have a value of 1
prop_positives = Y.mean()

# Print results
print(prop_positives)


# ### 6. Improve your model
# Use grid search to find better parameters. 

# In[ ]:






# Define parameters for grid search
parameters = {
    'tfidf__use_idf': (True, False),
    'clf__estimator__n_estimators': [10, 50, 100],
    'clf__estimator__min_samples_split': [2, 4]
}

# Perform grid search with cross-validation
cv = GridSearchCV(pipeline, param_grid=parameters)

# Fit the grid search object to the training data
cv.fit(X_train, Y_train)

# Print the best parameters
print(cv.best_params_)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# ### 7. Test your model
# Show the accuracy, precision, and recall of the tuned model.  
# 
# Since this project focuses on code quality, process, and  pipelines, there is no minimum performance metric needed to pass. However, make sure to fine tune your models for accuracy, precision and recall to make your project stand out - especially for your portfolio!

# In[ ]:


from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Make predictions on the test set
Y_pred = cv.predict(X_test)

# Calculate evaluation metrics
accuracy = accuracy_score(Y_test, Y_pred)
precision = precision_score(Y_test, Y_pred, average='weighted')
recall = recall_score(Y_test, Y_pred, average='weighted')
f1 = f1_score(Y_test, Y_pred, average='weighted')

# Print results
print(f"Accuracy: {accuracy}")
print(f"Precision: {precision}")
print(f"Recall: {recall}")
print(f"F1 score: {f1}")


# In[ ]:





# In[ ]:





# ### 8. Try improving your model further. Here are a few ideas:
# * try other machine learning algorithms
# * add other features besides the TF-IDF

# In[ ]:




# Define pipeline
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(tokenizer=tokenize)),
    ('clf', MultiOutputClassifier(RandomForestClassifier()))
])

# Define parameters for grid search
parameters = {
    'tfidf__use_idf': [True, False],
    'clf__estimator__n_estimators': [50, 100, 200],
    'clf__estimator__min_samples_split': [2, 5, 10]
}

# Perform grid search with cross-validation
cv = GridSearchCV(pipeline, param_grid=parameters, cv=3, verbose=2)

# Fit the grid search object to the training data
cv.fit(X_train, Y_train)

# Make predictions on the test set
Y_pred = cv.predict(X_test)

# Calculate evaluation metrics
accuracy = accuracy_score(Y_test, Y_pred)
precision = precision_score(Y_test, Y_pred, average='weighted')
recall = recall_score(Y_test, Y_pred, average='weighted')
f1 = f1_score(Y_test, Y_pred, average='weighted')

# Print results
print(f"Accuracy: {accuracy}")
print(f"Precision: {precision}")
print(f"Recall: {recall}")
print(f"F1 score: {f1}")


# In[ ]:





# In[ ]:





# ### 9. Export your model as a pickle file

# In[ ]:


import pickle

# Train your model
# ...

# Save the trained model as a pickle file
filename = 'model.pkl'
with open(filename, 'wb') as file:
    pickle.dump(cv.best_estimator_, file)


# ### 10. Use this notebook to complete `train.py`
# Use the template file attached in the Resources folder to write a script that runs the steps above to create a database and export a model based on a new dataset specified by the user.

# In[ ]:


import sys
import pandas as pd
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.multioutput import MultiOutputClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
import pickle

def load_data(database_filepath):
    """
    Load the data from the SQLite database into a pandas DataFrame
    """
    engine = create_engine('sqlite:///' + database_filepath)
    df = pd.read_sql_table('Disaster_Response', engine)
    X = df['message']
    Y = df.iloc[:, 4:]
    category_names = Y.columns.tolist()
    return X, Y, category_names

def tokenize(text):
    """
    Tokenize the text data by converting to lowercase, removing punctuation and stop words, and lemmatizing
    """
    # import libraries
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem.wordnet import WordNetLemmatizer
    import string

    # convert to lowercase
    text = text.lower()
    # remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # tokenize text
    tokens = word_tokenize(text)
    # remove stop words
    tokens = [t for t in tokens if t not in stopwords.words("english")]
    # lemmatize tokens
    lemmatizer = WordNetLemmatizer()
    clean_tokens = [lemmatizer.lemmatize(token) for token in tokens]

    return clean_tokens

def build_model():
    """
    Build a machine learning pipeline using CountVectorizer, TfidfTransformer, MultiOutputClassifier, and RandomForestClassifier
    """
    pipeline = Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer()),
        ('clf', MultiOutputClassifier(RandomForestClassifier()))
    ])
    
    parameters = {
        'vect__ngram_range': ((1, 1), (1, 2)),
        'tfidf__use_idf': (True, False),
        'clf__estimator__n_estimators': [10, 50],
        'clf__estimator__min_samples_split': [2, 4]
    }

    cv = GridSearchCV(pipeline, param_grid=parameters, verbose=2)

    return cv

def evaluate_model(model, X_train, Y_train, X_test, Y_test, category_names):
    """
    Evaluate the performance of the model on the test set
    """
    # Train and fit the model
    model.fit(X_train, Y_train)
    # Predict on the test set
    Y_pred = model.predict(X_test)
    # Print classification report
    print(classification_report(Y_test.values, Y_pred, target_names=category_names))

def save_model(model, model_filepath):
    """
    Save the model as a pickle file
    """
    with open(model_filepath, 'wb') as file:
        pickle.dump(model.best_estimator_, file)

def main():
    """
    Train the model and save it as a pickle file
    """
    if len(sys.argv) == 4:
        database_filepath, model_filepath, new_data_filepath = sys.argv[1:]
        # Load data
        X, Y, category_names = load_data(database_filepath)
        # Split into train and test sets
        X_train, X_test, Y_train, Y_test


# In[ ]:




